package com.example.error_tracker.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "api_errors")
public class ApiError {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String apiPath;
    private String errorMessage;
    private String stackTrace;
    private String requestMethod;
    private String requestParams;
    private String requestBody;
    private String clientIp;
    private int httpStatus;
    
    @Column(columnDefinition = "TIMESTAMP")
    private LocalDateTime timestamp;
    
    @PrePersist
    protected void onCreate() {
        timestamp = LocalDateTime.now();
    }
}
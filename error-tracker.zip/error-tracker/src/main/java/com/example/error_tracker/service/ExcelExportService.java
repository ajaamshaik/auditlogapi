package com.example.error_tracker.service;

import com.example.error_tracker.model.ApiError;
import com.example.error_tracker.repository.ApiErrorRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class ExcelExportService {
    
    @Autowired
    private ApiErrorRepository errorRepository;
    
    @Scheduled(cron = "0 0 * * * *") // Runs hourly at minute 0
    public void exportToExcelHourly() throws IOException {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime oneHourAgo = now.minusHours(1);
        
        List<ApiError> errors = errorRepository.findByTimestampBetween(oneHourAgo, now);
        
        if (!errors.isEmpty()) {
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("API Errors");
            
            // Create header row
            Row headerRow = sheet.createRow(0);
            String[] columns = {"ID", "API Path", "Error Message", "HTTP Status", "Timestamp", "Request Method", "Client IP"};
            
            for (int i = 0; i < columns.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns[i]);
            }
            
            // Create data rows
            int rowNum = 1;
            for (ApiError error : errors) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(error.getId());
                row.createCell(1).setCellValue(error.getApiPath());
                row.createCell(2).setCellValue(error.getErrorMessage());
                row.createCell(3).setCellValue(error.getHttpStatus());
                row.createCell(4).setCellValue(error.getTimestamp().toString());
                row.createCell(5).setCellValue(error.getRequestMethod());
                row.createCell(6).setCellValue(error.getClientIp());
            }
            
            // Auto-size columns
            for (int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }
            
            // Save the file
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
            String fileName = "error_report_" + now.format(formatter) + ".xlsx";
            
            try (FileOutputStream outputStream = new FileOutputStream(fileName)) {
                workbook.write(outputStream);
            }
            
            workbook.close();
        }
    }
}
package com.example.error_tracker.config;

import com.example.error_tracker.model.ApiError;
import com.example.error_tracker.repository.ApiErrorRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;

@ControllerAdvice
public class GlobalExceptionHandler {
    
    private final ApiErrorRepository errorRepository;
    
    public GlobalExceptionHandler(ApiErrorRepository errorRepository) {
        this.errorRepository = errorRepository;
    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request, HttpServletRequest httpRequest) {
        ApiError apiError = new ApiError();
        apiError.setApiPath(httpRequest.getRequestURI());
        apiError.setErrorMessage(ex.getMessage());
        apiError.setStackTrace(getStackTraceAsString(ex));
        apiError.setRequestMethod(httpRequest.getMethod());
        apiError.setRequestParams(httpRequest.getQueryString());
        apiError.setClientIp(httpRequest.getRemoteAddr());
        apiError.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        
        errorRepository.save(apiError);
        
        return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    private String getStackTraceAsString(Exception ex) {
        StringBuilder sb = new StringBuilder();
        for (StackTraceElement element : ex.getStackTrace()) {
            sb.append(element.toString());
            sb.append("\n");
        }
        return sb.toString();
    }
}
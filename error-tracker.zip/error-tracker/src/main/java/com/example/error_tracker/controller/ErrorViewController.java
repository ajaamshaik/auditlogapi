package com.example.error_tracker.controller;

import com.example.error_tracker.model.ApiError;
import com.example.error_tracker.repository.ApiErrorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.List;

@Controller
public class ErrorViewController {
    
    @Autowired
    private ApiErrorRepository errorRepository;
    
    @GetMapping("/errors")
    public String getErrors(
            @RequestParam(required = false) String period,
            Model model) {
        
        LocalDateTime end = LocalDateTime.now();
        LocalDateTime start;
        
        if ("day".equals(period)) {
            start = end.minusDays(1);
        } else if ("week".equals(period)) {
            start = end.minusWeeks(1);
        } else if ("month".equals(period)) {
            start = end.minusMonths(1);
        } else {
            // Default to last 24 hours
            start = end.minusHours(24);
        }
        
        List<ApiError> errors = errorRepository.findByTimestampBetween(start, end);
        model.addAttribute("errors", errors);
        return "errors";
    }
}
package com.example.error_tracker.repository;

import com.example.error_tracker.model.ApiError;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ApiErrorRepository extends JpaRepository<ApiError, Long> {
    List<ApiError> findByTimestampBetween(LocalDateTime start, LocalDateTime end);
}
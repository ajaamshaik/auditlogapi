package com.example.error_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErrorTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}

// src/main/java/com/example/apitracker/autoconfigure/ErrorTrackerProperties.java
@ConfigurationProperties(prefix = "api.error.tracker")
public class ErrorTrackerProperties {
    private boolean enabled = true;
    private int stackTraceLimit = 50;
    
    // Getters and setters
}
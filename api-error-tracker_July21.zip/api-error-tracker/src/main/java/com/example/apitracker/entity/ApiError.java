package com.example.apitracker.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiError {
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
        @Column(nullable = false)
    private String path;

        @Column(nullable = false)
    private String method;

    @Column(nullable = false)
    private int statusCode;

      @Column(length = 4000)
    private String errorMessage;
    private String exceptionType;
    
     @Column(columnDefinition = "CLOB")  // H2-specific CLOB type
private String stackTrace;
    
    @CreationTimestamp
    private LocalDateTime timestamp;
    
    @Column(nullable = false)
    private String clientIp;

   
    private String requestParams;

       @Column(columnDefinition = "CLOB")
    private String requestHeaders;
}
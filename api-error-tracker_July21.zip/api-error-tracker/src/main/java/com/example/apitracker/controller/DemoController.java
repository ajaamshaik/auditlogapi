package com.example.apitracker.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class DemoController {

    @GetMapping("/ok")
    public String okEndpoint() {
        return "Everything is OK";
    }

    @GetMapping("/error/{type}")
    public String errorEndpoint(@PathVariable String type) {
        if ("runtime".equals(type)) {
            throw new RuntimeException("Sample runtime exception");
        } else if ("illegal".equals(type)) {
            throw new IllegalArgumentException("Invalid argument provided");
        } else if ("custom".equals(type)) {
            throw new CustomBusinessException("Business rule violation");
        }
        return "No error generated";
    }
    
    static class CustomBusinessException extends RuntimeException {
        public CustomBusinessException(String message) {
            super(message);
        }
    }
}
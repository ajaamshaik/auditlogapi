package com.example.apitracker.autoconfigure;

import com.example.apitracker.aspect.ErrorTrackingAspect;
import com.example.apitracker.config.AsyncConfig;
import com.example.apitracker.config.MetricsConfig;
import com.example.apitracker.repository.ApiErrorRepository;
import com.example.apitracker.service.AsyncErrorTracker;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ConditionalOnWebApplication
@ConditionalOnClass(ErrorTrackingAspect.class)
@Import({AsyncConfig.class, MetricsConfig.class})
public class ErrorTrackerAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public AsyncErrorTracker asyncErrorTracker(ApiErrorRepository errorRepository) {
        return new AsyncErrorTracker(errorRepository);
    }

    @Bean
    @ConditionalOnMissingBean
    public ErrorTrackingAspect errorTrackingAspect(AsyncErrorTracker errorTracker) {
        return new ErrorTrackingAspect(errorTracker);
    }
}
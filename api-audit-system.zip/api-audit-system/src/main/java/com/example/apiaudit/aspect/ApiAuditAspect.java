package com.example.apiaudit.aspect;

import com.example.apiaudit.model.ApiAuditLog;
import com.example.apiaudit.service.ApiAuditService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Aspect
@Component
public class ApiAuditAspect {
    
    private static final Logger logger = LoggerFactory.getLogger(ApiAuditAspect.class);
    
    private final ApiAuditService apiAuditService;
    
    @Autowired
    public ApiAuditAspect(ApiAuditService apiAuditService) {
        this.apiAuditService = apiAuditService;
    }
    
    @Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
    public void restController() {}
    
    @Pointcut("within(@org.springframework.stereotype.Controller *)")
    public void controller() {}
    
    @Around("restController() || controller()")
    public Object auditApiCall(ProceedingJoinPoint joinPoint) throws Throwable {
        LocalDateTime startTime = LocalDateTime.now();
        Throwable exception = null;
        Object result = null;
        
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        
        try {
            result = joinPoint.proceed();
            return result;
        } catch (Throwable t) {
            exception = t;
            throw t;
        } finally {
            try {
                ApiAuditLog auditLog = apiAuditService.createAuditLog(
                    className, methodName,
                    joinPoint.getArgs(), result,
                    startTime, exception);
                
                apiAuditService.logApiCall(auditLog);
            } catch (Exception e) {
                logger.error("Failed to create audit log for {}.{}", className, methodName, e);
            }
        }
    }
}
package com.example.apiaudit.repository;

import com.example.apiaudit.model.ApiAuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ApiAuditLogRepository extends JpaRepository<ApiAuditLog, Long> {
    
    @Query("SELECT a FROM ApiAuditLog a WHERE " +
           "(:#{#endpoint} IS NULL OR a.endpoint = :#{#endpoint}) AND " +
           "(:#{#status} IS NULL OR a.status = :#{#status}) AND " +
           "(:#{#from} IS NULL OR a.timestamp >= :#{#from}) AND " +
           "(:#{#to} IS NULL OR a.timestamp <= :#{#to})")
    Page<ApiAuditLog> findByFilters(
        @Param("endpoint") String endpoint,
        @Param("status") String status,
        @Param("from") LocalDateTime from,
        @Param("to") LocalDateTime to,
        Pageable pageable);
    
    @Query("SELECT DISTINCT a.endpoint FROM ApiAuditLog a")
    List<String> findAllUniqueEndpoints();
    
    @Query("SELECT a FROM ApiAuditLog a WHERE " +
           "(:#{#endpoint} IS NULL OR a.endpoint = :#{#endpoint}) AND " +
           "(:#{#status} IS NULL OR a.status = :#{#status}) AND " +
           "(:#{#from} IS NULL OR a.timestamp >= :#{#from}) AND " +
           "(:#{#to} IS NULL OR a.timestamp <= :#{#to}) " +
           "ORDER BY a.timestamp DESC")
    List<ApiAuditLog> findByFiltersForExport(
        @Param("endpoint") String endpoint,
        @Param("status") String status,
        @Param("from") LocalDateTime from,
        @Param("to") LocalDateTime to);
}
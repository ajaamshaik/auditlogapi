package com.example.apiaudit.service;

import com.example.apiaudit.model.ApiAuditLog;
import com.example.apiaudit.repository.ApiAuditLogRepository;
import com.example.apiaudit.util.DataMaskingUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class ApiAuditService {
    
    private static final Logger logger = LoggerFactory.getLogger(ApiAuditService.class);
    
    private final ApiAuditLogRepository auditLogRepository;
    private final ObjectMapper objectMapper;
    
    public ApiAuditService(ApiAuditLogRepository auditLogRepository, ObjectMapper objectMapper) {
        this.auditLogRepository = auditLogRepository;
        this.objectMapper = objectMapper;
    }
    
    @Async
    public void logApiCall(ApiAuditLog auditLog) {
        try {
            auditLogRepository.save(auditLog);
            logger.debug("Audit log saved successfully for {}", auditLog.getEndpoint());
        } catch (Exception e) {
            logger.error("Failed to save audit log for endpoint: {}", auditLog.getEndpoint(), e);
        }
    }
    
    public ApiAuditLog createAuditLog(String className, String methodName,
                                    Object[] args, Object result,
                                    LocalDateTime startTime, Throwable exception) {
        
        ApiAuditLog auditLog = new ApiAuditLog();
        auditLog.setClassName(className);
        auditLog.setMethodName(methodName);
        auditLog.setExecutionTime(Duration.between(startTime, LocalDateTime.now()).toMillis());
        
        try {
            // Get HTTP request information if available
            Optional.ofNullable(RequestContextHolder.getRequestAttributes())
                .filter(ServletRequestAttributes.class::isInstance)
                .map(ServletRequestAttributes.class::cast)
                .ifPresent(requestAttributes -> {
                    HttpServletRequest request = requestAttributes.getRequest();
                    auditLog.setHttpMethod(request.getMethod());
                    auditLog.setEndpoint(request.getRequestURI());
                    auditLog.setClientIp(request.getRemoteAddr());
                    auditLog.setUserAgent(request.getHeader("User-Agent"));
                });
            
            // Process request payload
            if (args != null && args.length > 0) {
                String requestJson = objectMapper.writeValueAsString(args);
                auditLog.setRequestPayload(DataMaskingUtil.maskSensitiveData(requestJson));
            }
            
            // Process response payload
            if (result != null) {
                String responseJson = objectMapper.writeValueAsString(result);
                auditLog.setResponsePayload(DataMaskingUtil.maskSensitiveData(responseJson));
            }
            
            // Handle errors
            if (exception != null) {
                auditLog.setStatus("ERROR");
                auditLog.setErrorMessage(exception.getMessage());
            }
        } catch (Exception e) {
            logger.warn("Failed to process audit log data", e);
            auditLog.setStatus("ERROR");
            auditLog.setErrorMessage("Audit processing error: " + e.getMessage());
        }
        
        return auditLog;
    }
}
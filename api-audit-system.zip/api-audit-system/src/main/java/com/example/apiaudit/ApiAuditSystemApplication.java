package com.example.apiaudit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiAuditSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiAuditSystemApplication.class, args);
	}

}

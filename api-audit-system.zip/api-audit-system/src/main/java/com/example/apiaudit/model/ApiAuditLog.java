package com.example.apiaudit.model;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "api_audit_logs", indexes = {
    @Index(name = "idx_endpoint", columnList = "endpoint"),
    @Index(name = "idx_timestamp", columnList = "timestamp"),
    @Index(name = "idx_status", columnList = "status")
})
public class ApiAuditLog {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, length = 10)
    private String httpMethod;
    
    @Column(nullable = false, length = 255)
    private String endpoint;
    
    @Column(nullable = false, length = 100)
    private String className;
    
    @Column(nullable = false, length = 100)
    private String methodName;
    
    @Column(columnDefinition = "TEXT")
    private String requestPayload;
    
    @Column(columnDefinition = "TEXT")
    private String responsePayload;
    
    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime timestamp;
    
    private Long executionTime; // in milliseconds
    
    @Column(length = 50)
    private String userId;
    
    @Column(nullable = false, length = 20)
    private String status = "SUCCESS"; // SUCCESS, ERROR
    
    @Column(columnDefinition = "TEXT")
    private String errorMessage;
    
    @Column(length = 50)
    private String clientIp;
    
    @Column(length = 255)
    private String userAgent;
}
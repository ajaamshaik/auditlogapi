package com.example.apiaudit.config;

import com.example.apiaudit.aspect.ApiAuditAspect;
import com.example.apiaudit.repository.ApiAuditLogRepository;
import com.example.apiaudit.service.ApiAuditService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;

@Configuration
@EnableAsync
@ConditionalOnClass(name = "org.springframework.web.bind.annotation.RestController")
@EntityScan("com.example.apiaudit.model")
@EnableJpaRepositories("com.example.apiaudit.repository")
public class ApiAuditAutoConfiguration {
    
    @Bean
    @ConditionalOnMissingBean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }
    
    @Bean
    @ConditionalOnMissingBean
    public ApiAuditService apiAuditService(ApiAuditLogRepository repository, ObjectMapper mapper) {
        return new ApiAuditService(repository, mapper);
    }
    
    @Bean
    @ConditionalOnMissingBean
    public ApiAuditAspect apiAuditAspect(ApiAuditService service) {
        return new ApiAuditAspect(service);
    }
}
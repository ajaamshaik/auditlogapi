package com.example.apiaudit.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class DataMaskingUtil {
    
    private static final String MASK = "*****";
    private static final ObjectMapper objectMapper = new ObjectMapper();
    
    private static final String[] SENSITIVE_FIELDS = {
        "password", "creditCard", "ssn", "cvv", 
        "token", "secret", "apiKey", "authorization"
    };
    
    public static String maskSensitiveData(String json) {
        try {
            JsonNode node = objectMapper.readTree(json);
            maskSensitiveFields(node);
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            return json; // Return original if masking fails
        }
    }
    
    private static void maskSensitiveFields(JsonNode node) {
        if (node.isObject()) {
            ObjectNode objectNode = (ObjectNode) node;
            
            // Check all sensitive fields
            for (String field : SENSITIVE_FIELDS) {
                if (objectNode.has(field)) {
                    objectNode.put(field, MASK);
                }
            }
            
            // Recursively process child nodes
            node.fields().forEachRemaining(entry -> {
                if (entry.getValue().isObject() || entry.getValue().isArray()) {
                    maskSensitiveFields(entry.getValue());
                }
            });
        } else if (node.isArray()) {
            node.forEach(DataMaskingUtil::maskSensitiveFields);
        }
    }
}
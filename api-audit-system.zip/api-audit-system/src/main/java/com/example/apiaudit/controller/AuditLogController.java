package com.example.apiaudit.controller;

import com.example.apiaudit.model.ApiAuditLog;
import com.example.apiaudit.repository.ApiAuditLogRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Controller
public class AuditLogController {

    private final ApiAuditLogRepository auditLogRepository;
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    public AuditLogController(ApiAuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    @GetMapping("/audit-logs")
    public String getAuditLogs(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "timestamp,desc") String[] sort,
            @RequestParam(required = false) String endpoint,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String fromDate,
            @RequestParam(required = false) String toDate,
            Model model) {

        // Create page request with sorting
        String[] sortParams = sort[0].split(",");
        String sortField = sortParams[0];
        Sort.Direction sortDirection = sortParams.length > 1 
            ? Sort.Direction.fromString(sortParams[1]) 
            : Sort.Direction.DESC;
        
        Sort sorting = Sort.by(sortDirection, sortField);
        Pageable pageable = PageRequest.of(page, size, sorting);

        // Convert date strings to LocalDateTime
        LocalDateTime from = fromDate != null ? LocalDateTime.parse(fromDate, formatter) : null;
        LocalDateTime to = toDate != null ? LocalDateTime.parse(toDate, formatter) : null;

        // Get filtered results
        Page<ApiAuditLog> logsPage;
        if (endpoint != null || status != null || from != null || to != null) {
            logsPage = auditLogRepository.findByFilters(
                    endpoint, status, from, to, pageable);
        } else {
            logsPage = auditLogRepository.findAll(pageable);
        }

        // Get distinct endpoints for dropdown
        List<String> endpoints = auditLogRepository.findAllUniqueEndpoints();

        // Add data to model
        model.addAttribute("logs", logsPage);
        model.addAttribute("endpoints", endpoints);
        model.addAttribute("currentPage", page);
        model.addAttribute("pageSize", size);
        model.addAttribute("sort", sort[0]);
        model.addAttribute("endpointFilter", endpoint);
        model.addAttribute("statusFilter", status);
        model.addAttribute("fromDateFilter", fromDate);
        model.addAttribute("toDateFilter", toDate);

        return "audit-logs";
    }

    @GetMapping("/audit-logs/export")
    public void exportAuditLogs(
            @RequestParam(required = false) String endpoint,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String fromDate,
            @RequestParam(required = false) String toDate,
            HttpServletResponse response) throws IOException {

        // Convert date strings to LocalDateTime
        LocalDateTime from = fromDate != null ? LocalDateTime.parse(fromDate, formatter) : null;
        LocalDateTime to = toDate != null ? LocalDateTime.parse(toDate, formatter) : null;

        // Get filtered results
        List<ApiAuditLog> logs = auditLogRepository.findByFiltersForExport(
                endpoint, status, from, to);

        // Set response headers
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=audit-logs.csv");

        // Write CSV
        try (PrintWriter writer = response.getWriter()) {
            writer.write("Timestamp,HTTP Method,Endpoint,Class/Method,Status,Execution Time (ms),User ID,Client IP\n");
            for (ApiAuditLog log : logs) {
                writer.write(String.format("\"%s\",\"%s\",\"%s\",\"%s.%s()\",\"%s\",%d,\"%s\",\"%s\"\n",
                        formatter.format(log.getTimestamp()),
                        log.getHttpMethod(),
                        log.getEndpoint(),
                        log.getClassName(),
                        log.getMethodName(),
                        log.getStatus(),
                        log.getExecutionTime(),
                        log.getUserId() != null ? log.getUserId() : "",
                        log.getClientIp() != null ? log.getClientIp() : ""));
            }
        }
    }
}
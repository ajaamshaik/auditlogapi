# API Audit System

A complete Spring Boot application that:
1. Automatically audits all API requests and responses
2. Stores the audit logs in a database
3. Provides a web UI to view and filter the audit logs
4. Supports CSV export of audit data

## Features

- Automatic payload capture
- Sensitive data masking
- Database storage
- Search and filtering
- Pagination
- CSV export
- Secure access (admin-only)

## Setup

1. Install PostgreSQL and create a database named `audit_db`
2. Update the database credentials in `application.yml`
3. Build and run the application:
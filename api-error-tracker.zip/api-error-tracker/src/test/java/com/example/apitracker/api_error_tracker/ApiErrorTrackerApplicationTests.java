package com.example.apitracker.api_error_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiErrorTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}

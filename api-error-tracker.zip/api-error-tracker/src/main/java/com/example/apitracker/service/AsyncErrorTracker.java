package com.example.apitracker.service;

import com.example.apitracker.entity.ApiError;
import com.example.apitracker.repository.ApiErrorRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j  // This provides the 'log' variable
public class AsyncErrorTracker {
    
    private final ApiErrorRepository errorRepository;
    
  @Async("errorTrackingExecutor")
public void trackErrorAsync(HttpServletRequest request, Exception ex) {
    try {
        log.debug("Tracking error - Path: {}, Method: {}, Client IP: {}", 
            request.getRequestURI(), 
            request.getMethod(),
            request.getRemoteAddr());
        
        log.debug("Exception: {} - {}", ex.getClass().getName(), ex.getMessage());
        
        ApiError error = ApiError.builder()
            .path(request.getRequestURI())
            .method(request.getMethod())
            .errorMessage(ex.getMessage())
            .exceptionType(ex.getClass().getName())
            .stackTrace(truncateStackTrace(ex))
            .clientIp(request.getRemoteAddr())
            .requestParams(request.getQueryString())
            .requestHeaders(getEssentialHeaders(request))
            .build();
            
        log.debug("Built error entity: {}", error);
        errorRepository.save(error);
    } catch (Exception e) {
        log.error("Error tracking failed", e);
    }
}
    
  private String truncateStackTrace(Exception ex) {
    return Arrays.stream(ex.getStackTrace())
               .limit(20)  // Reduced from 50 to 20 frames
               .map(StackTraceElement::toString)
               .collect(Collectors.joining("\n"));
}
    
    private String getEssentialHeaders(HttpServletRequest request) {
        return String.format("User-Agent: %s | Content-Type: %s | Accept: %s",
                request.getHeader("User-Agent"),
                request.getHeader("Content-Type"),
                request.getHeader("Accept"));
    }
}
package com.example.apitracker.repository;

import com.example.apitracker.entity.ApiError;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ApiErrorRepository extends JpaRepository<ApiError, Long> {
    
    @Override
    @CacheEvict(value = "errors", allEntries = true)
    <S extends ApiError> S save(S entity);
    
    @Cacheable("errors")
    default List<ApiError> findRecentErrors() {
        return findAll(Pageable.ofSize(100)).getContent();
    }
    
    Page<ApiError> findByPathContaining(String path, Pageable pageable);
}
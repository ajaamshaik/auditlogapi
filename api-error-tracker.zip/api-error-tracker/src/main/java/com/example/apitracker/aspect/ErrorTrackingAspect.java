package com.example.apitracker.aspect;

import com.example.apitracker.service.AsyncErrorTracker;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Aspect
@Component
@RequiredArgsConstructor
public class ErrorTrackingAspect  {
    
    private final AsyncErrorTracker errorTracker;
    
    @AfterThrowing(
        pointcut = "@within(org.springframework.web.bind.annotation.RestController) || " +
                  "@annotation(org.springframework.web.bind.annotation.RestController)",
        throwing = "ex"
    )
    public void trackError(JoinPoint joinPoint, Exception ex) {
        HttpServletRequest request = 
            ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        
        errorTracker.trackErrorAsync(request, ex);
    }
}